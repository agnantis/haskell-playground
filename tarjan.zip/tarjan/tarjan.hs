module Tarjan where

import Data.Array
import Data.Tuple
-- import Data.Graph hiding (Table, Graph, vertices, Edge, Bounds, graph, buildG, Vertex, edges)

type Vertex = Char
type Table a = Array Vertex a
type Graph = Table [Vertex]
type Edge = (Vertex,Vertex)
type Bounds = (Vertex,Vertex)

vertices :: Graph -> [Vertex]
vertices = indices

edges :: Graph -> [Edge]
edges g = [ (v,w) | v <- vertices g, w <- g!v ]

mapT :: (Vertex -> a -> b) -> Table a -> Table b
mapT f t = array (bounds t) [(v, f v (t!v)) | v <- indices t]

outdegree :: Graph -> Table Int
outdegree = mapT (const length)

indegree :: Graph -> Table Int
indegree = outdegree . transposeG 

buildG :: Bounds -> [Edge] -> Graph
buildG bnds = accumArray (flip (:)) [] bnds 

transposeG :: Graph -> Graph
transposeG g = buildG (bounds g) (reverseE g)

reverseE :: Graph -> [Edge]
reverseE = (map swap) . edges

graph :: Graph
graph = buildG ('a', 'j')
          [('a', 'j'), ('a', 'g'), ('b', 'i'),
           ('b', 'a'), ('c', 'h'), ('c', 'e'),
           ('e', 'j'), ('e', 'h'), ('e', 'd'),
           ('f', 'i'), ('g', 'f'), ('g', 'b')]   

--------------------------
--  Depth-first search  --
--------------------------

data Tree a   = Node a (Forest a)
type Forest a = [Tree a]

dfs :: Graph -> [Vertex] -> Forest Vertex
dfs g v = fst $ foldl folder ([], []) v

folder :: (Forest Vertex, [Vertex]) -> Vertex -> (Forest Vertex, [Vertex])
folder (fs, vs) nv = undefined

dff :: Graph -> Forest Vertex
dff g = dfs g (vertices g)

preorder :: Tree a -> [a]
preorder (Node a ts) = a:preorderF ts

preorderF :: Forest a -> [a]
preorderF = concatMap preorder

preOrd :: Graph -> [Vertex]
preOrd = preorderF . dff

tabulate :: Bounds -> [Vertex] -> Table Int
tabulate bnds vs = array bnds (zip vs [1..])

preArr :: Bounds -> Forest Vertex -> Table Int
preArr bnds = tabulate bnds . preorderF
